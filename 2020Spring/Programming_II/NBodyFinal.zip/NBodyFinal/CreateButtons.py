# -*- coding:utf-8 -*-

import tkinter
import tkinter.font as Font
from functools import partial

root = tkinter.Tk()

# define my font
myFontHelvetica = font.Font(family='Helvetica', size=18, weight='bold')


class CreateButton:
    def __init__(self)
